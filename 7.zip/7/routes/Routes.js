const Express = require('express')
const Routes = Express.Router()

//Compo
const UserControllers = require('../controllers/Users')
const SequelizeControllers = require('../controllers/sequelize')



Routes.post('/users/login', UserControllers.Login)
Routes.post('/users/register', UserControllers.Register)
Routes.post('/users/logout', UserControllers.Logout)
Routes.post('/users/online', UserControllers.OnlineStatus)
Routes.get('/sequelize', SequelizeControllers.Tester)

Routes.get('/', (req, res) => { res.render('index') })
Routes.get('/login', (req,res) => { res.render('login') })
Routes.get('/logout', (req, res) => { res.render('logout') })
Routes.get('/online-users', (req, res) => { res.render('online_users') })
Routes.get('/games', (req, res) => { res.render('chapter4') })


module.exports = Routes