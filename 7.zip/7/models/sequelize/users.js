const { Sequelize, DataTypes } = require('sequelize')

const sequelize = new Sequelize('mysql::memory:')

const User = sequelize.define(
    'user',
    {
        username:{
            type: DataTypes.STRING,
            allowNull: true,
        },

        password:{
            type: DataTypes.STRING,
            allowNull: true,
        }
    }
)

console.log(User === sequelize.models.User)