const Express = require('express')
const Cryptr = require('cryptr')
const newCryptr = new Cryptr('Secret')
const CryptrF = new Cryptr('SecretKey')

//models
const UsersModel = require ('../models/MongoDB/Users')
const LoginActivityModels = require('../models/MongoDB/LoginActivity')
const ProfilesModel = require ('../models/MongoDB/Profiles')
const ProductsModel = require ('../models/MongoDB/Products')
const { response } = require('express')
const app = Express

// const ConnectionMongoDB = require('../models/MongoDB/Connection')
// ConnectionMongoDB()

//controllers
const JWTCheck = require('./JWTCheck')
// Models
 


const Register = (req,res) => {
    let dataUser = req.body
    let newPassword = newCryptr.encrypt(dataUser.password)

    const User = new UsersModel({
        username: dataUser.username,
        password: newPassword,
        fullname: dataUser.fullname,
        age: dataUser.age,
        address: dataUser.address,
        email: dataUser.email
    
    })

    User.save(User).then(SavedData => {
        res.send ({
            message: `successful to create data user`,
            data: SavedData,
            status:200
        })
    }).catch(err=> {
        console.log(err)
        res.send({
            message: `failed to create user data`,
            status: 500
        })
    })
}



const  Login = (req, res) => {
    let dataUser = req.body
    console.log(req.body)

    UsersModel.findOne({
        'username': dataUser.username,
    }).then(response => {
        if( !response) {
            console.log(response)
            console.log(`tidak ada data user ${dataUser.username}`)
            res.send(`tidak ada data user ${dataUser.username}`)
        } else {
            let decryptPassword = newCryptr.decrypt(response.password)
            if ( decryptPassword != dataUser.password ) {
                res.status(401).send('password do not match')
            } else {
                LoginActivityModels.findOne({ 'username': response.username }).then(ResLogAct => {
                    if ( ResLogAct != null ) {
                        console.log('login activity is not null')
                        res.send({ message: `Successful to login`, status: 200, data: response.users})
                    }else {
                        let Token = JWTCheck.Create({ uid: response._id, username: response.username, fullname: response.fullname, age: response.age, email: response.email })
                        let PassingDataUser = {
                            uid: response._id,
                            username: response.username,
                            fullname: response.fullname,
                            age: response.age,
                            address: response.address,
                            email: response.email,
                            token_type: 'Bearer',
                            token: Token
                        }

                        const LoginActivityData = new LoginActivityModels({
                            uid: response._id,
                            username: response.username,
                            users: PassingDataUser
                        })

                        LoginActivityData.save(LoginActivityData).then(ResCreate => {
                            res.send({ message: `Successful to login`, status: 200, data: PassingDataUser})
                        }).catch(err => {
                            res.send({ message: `failed to create login act`, status:500})
                        })
                    }
                }).catch(err =>{
                    res.send({ message : `failed to find login act`})
                })   
            }
        }
    }).catch(err => {
        console.log(err)
        res.send('failed find data')
    })
}

const Logout = (req, res) => {
    console.log(req.body)

    let TokenAuth = req.headers.authorization.split(' ')
    if ( TokenAuth[0].toLowerCase() !== 'bearer' ) {
        res.send({ message: `failed, dont have authorization`, status: 403 })
    } else {
        let TokenCheck = JWTCheck.Check(TokenAuth[1])
        if ( TokenCheck.data.uid !== req.body.uid ) {
            res.send({ message: `failed to logout user, wrong id`, status: 401 })
        } else {
            LoginActivityModels.deleteOne({ 'uid': req.body.uid }).then(response => {
                res.send({ message: `Successfull to logout user`, status: 200 })
            }).catch(err => {
                res.send({ message: `failed to logout user, wrong id`, status: 401 })
            })
        }
    }
}

const OnlineStatus = (req, res) => {
    LoginActivityModels.find().select([
        'userdata.username',
        'userdata.fullname',
        'userdata.age',
        'userdata.address',
        'userdata.uid'
    ]).then(response => {
        res.send(response)
    }).catch(err => {
        console.log(err)
    })
}

exports.Login = Login
exports.Register = Register
exports.Logout = Logout
exports.OnlineStatus = OnlineStatus